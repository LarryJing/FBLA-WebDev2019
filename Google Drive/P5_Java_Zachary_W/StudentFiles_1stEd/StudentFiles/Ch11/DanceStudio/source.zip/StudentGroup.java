public interface StudentGroup
{
  void setup(int floorDir, Dance steps1, Dance steps2);
  void makeNextStep();
  void draw(java.awt.Graphics g);
}
