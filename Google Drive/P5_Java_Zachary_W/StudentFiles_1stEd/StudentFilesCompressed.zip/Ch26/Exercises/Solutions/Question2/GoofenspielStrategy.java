public interface GoofenspielStrategy
{
  int getMove(int[] hand);
}