public interface Stack 
{
  boolean isEmpty();
  Object peek();
  void push(Object obj);
  Object pop();
}
