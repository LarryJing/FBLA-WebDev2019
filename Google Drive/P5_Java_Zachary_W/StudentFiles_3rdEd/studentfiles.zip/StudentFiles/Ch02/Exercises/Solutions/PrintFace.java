// Chapter 2 Question 9

public class PrintFace
{
  public static void main(String[] args)
  {
    System.out.println("   xxxxx   ");
    System.out.println("  x     x  ");
    System.out.println("((  o o  ))");
    System.out.println("  |  V  |  ");
    System.out.println("  | === |  ");
    System.out.println("   -----   ");
  }
}
